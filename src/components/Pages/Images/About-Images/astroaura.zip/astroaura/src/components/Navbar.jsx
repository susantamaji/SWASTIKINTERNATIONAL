import React from "react";
import { Link } from "react-router-dom";

function Navbar() {
  return (
    <nav className="w-full bg-[#1a1a1a] py-4 fixed top-0 left-0 z-50">
      <div className="max-w-7xl mx-auto flex items-center justify-between px-6">

        {/* Logo */}
        <div className="flex items-center gap-2">
          <img 
            src="/logo.png" 
            alt="logo" 
            className="w-10 h-10"
          />
          <h1 className="text-white text-2xl font-semibold">AstroAura</h1>
        </div>

        {/* Menu */}
        <ul className="flex items-center gap-8 text-white text-sm font-medium">

          <li className="relative group cursor-pointer">
            <Link to="/">Home</Link>
            <span className="absolute left-0 -bottom-1 h-0.5 w-full bg-purple-500 scale-x-100"></span>
          </li>

          <li className="relative group cursor-pointer">
            <Link to="/about">About Us</Link>
            <span className="absolute left-0 -bottom-1 h-0.5 w-full bg-purple-500 scale-x-0 group-hover:scale-x-100 transition origin-left"></span>
          </li>

          <li className="relative group cursor-pointer">
            <Link to="/services">Services</Link>
            <span className="absolute left-0 -bottom-1 h-0.5 w-full bg-purple-500 scale-x-0 group-hover:scale-x-100 transition origin-left"></span>
          </li>

          <li className="relative group cursor-pointer">
            <Link to="/blog">Blogs</Link>
            <span className="absolute left-0 -bottom-1 h-0.5 w-full bg-purple-500 scale-x-0 group-hover:scale-x-100 transition origin-left"></span>
          </li>

          <li className="relative group cursor-pointer">
            <Link to="/contact">Contact</Link>
            <span className="absolute left-0 -bottom-1 h-0.5 w-full bg-purple-500 scale-x-0 group-hover:scale-x-100 transition origin-left"></span>
          </li>

        </ul>

      </div>
    </nav>
  );
}

export default Navbar;
